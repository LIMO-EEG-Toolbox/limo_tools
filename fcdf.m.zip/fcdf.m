function cdf = fcdf(x,m,n)

% This file returns the p value of x
% This is a pure copy of the fcdf function from Octave
% Octave is free software; Author: KH <Kurt.Hornik@wu-wien.ac.at> 


 	if (nargin ~= 3)
 		print_usage ();
    end

 	if (~isscalar (m) || ~isscalar (n))
 	[retval, x, m, n] = common_size (x, m, n);
 		if (retval > 0)
 			error ('fcdf: x, m and n must be of common size or scalar');
        end
    end

 	sz = size (x);
 	cdf = zeros (sz);

 	k = find (~(m > 0) | ~(n > 0) | isnan (x));
 	if (any (k))
 		cdf(k) = NaN;
    end

 	k = find ((x == Inf) & (m > 0) & (n > 0));
 	if (any (k))
 		cdf(k) = 1;
    end

 	k = find ((x > 0) & (x < Inf) & (m > 0) & (n > 0));
 	if (any (k))
         if (isscalar (m) && isscalar (n))
 			cdf(k) = 1 - betainc (1 ./ (1 + m .* x(k) ./ n), n / 2, m / 2);
 		else
 			cdf(k) = 1 - betainc (1 ./ (1 + m(k) .* x(k) ./ n(k)), n(k) / 2,m(k) / 2);
         end
    end


